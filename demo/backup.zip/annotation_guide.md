# Vegetation Management: data and model credits

- Data: OAM-TCD (Restor Foundation Tree Crown Delineation), OpenAerialMap aerial tree-crown imagery (https://huggingface.co/datasets/restor/tcd)
- Attribution: Aerial imagery from OpenAerialMap contributors, tree-crown annotations from the Restor Foundation OAM-TCD dataset (restor/tcd on Hugging Face). Licensed CC BY 4.0. Only CC-BY-4.0-licensed tiles are used.
- License: CC BY 4.0
- Pre-label model: Urban Tree Segmentation (https://universe.roboflow.com/tree-density-detection/urban-tree-segmentation/model/3). Pre-trained only; nothing was trained on these images.